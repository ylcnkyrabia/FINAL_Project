
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB1OA3m3Jhzs7pfIbgJ1CrS1ObVfUyfSLE",
    authDomain: "myproject-c0759.firebaseapp.com",
    databaseURL: "https://myproject-c0759.firebaseio.com",
    projectId: "myproject-c0759",
    storageBucket: "myproject-c0759.appspot.com",
    messagingSenderId: "789901643580"
  };
  firebase.initializeApp(config);
