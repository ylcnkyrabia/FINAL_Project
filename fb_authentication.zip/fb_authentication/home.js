var signOut_btn = document.querySelector("#signOut_btn");


function signOut(event){
	firebase.auth().signOut();
}


firebase.auth().onAuthStateChanged(function(user) {
  if (!user) {
    window.location.href = "login.html"
  }
});

signOut_btn.addEventListener('click', signOut)